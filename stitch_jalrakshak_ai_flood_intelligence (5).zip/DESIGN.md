---
name: Hydro-Tactical Command
colors:
  surface: '#0f131d'
  surface-dim: '#0f131d'
  surface-bright: '#353944'
  surface-container-lowest: '#0a0e18'
  surface-container-low: '#171b26'
  surface-container: '#1c1f2a'
  surface-container-high: '#262a35'
  surface-container-highest: '#313540'
  on-surface: '#dfe2f1'
  on-surface-variant: '#bbc9ce'
  inverse-surface: '#dfe2f1'
  inverse-on-surface: '#2c303b'
  outline: '#859398'
  outline-variant: '#3c494d'
  surface-tint: '#00d9ff'
  primary: '#afecff'
  on-primary: '#003641'
  primary-container: '#00d9ff'
  on-primary-container: '#005b6c'
  inverse-primary: '#00687b'
  secondary: '#ffb59d'
  on-secondary: '#5d1900'
  secondary-container: '#b83900'
  on-secondary-container: '#ffddd2'
  tertiary: '#ffdad8'
  on-tertiary: '#680011'
  tertiary-container: '#ffb3b1'
  on-tertiary-container: '#a90022'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#aeecff'
  primary-fixed-dim: '#00d9ff'
  on-primary-fixed: '#001f26'
  on-primary-fixed-variant: '#004e5d'
  secondary-fixed: '#ffdbd0'
  secondary-fixed-dim: '#ffb59d'
  on-secondary-fixed: '#390c00'
  on-secondary-fixed-variant: '#832600'
  tertiary-fixed: '#ffdad8'
  tertiary-fixed-dim: '#ffb3b1'
  on-tertiary-fixed: '#410007'
  on-tertiary-fixed-variant: '#92001c'
  background: '#0f131d'
  on-background: '#dfe2f1'
  surface-variant: '#313540'
typography:
  headline-2xl:
    fontFamily: Space Grotesk
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.03em
  headline-2xl-mobile:
    fontFamily: Space Grotesk
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-xl:
    fontFamily: Space Grotesk
    fontSize: 36px
    fontWeight: '600'
    lineHeight: 44px
    letterSpacing: -0.025em
  headline-xl-mobile:
    fontFamily: Space Grotesk
    fontSize: 26px
    fontWeight: '600'
    lineHeight: 34px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.02em
  headline-sm:
    fontFamily: Space Grotesk
    fontSize: 18px
    fontWeight: '500'
    lineHeight: 26px
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: -0.01em
  body-base:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0em
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
    letterSpacing: 0.01em
  telemetry-lg:
    fontFamily: JetBrains Mono
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.02em
  telemetry-base:
    fontFamily: JetBrains Mono
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 18px
    letterSpacing: 0em
  telemetry-caption:
    fontFamily: JetBrains Mono
    fontSize: 10px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.05em
  label-uppercase:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.08em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  space-2xs: 0.125rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-lg: 1rem
  space-xl: 1.5rem
  space-2xl: 2rem
  space-3xl: 3rem
  grid-gutter: 0.75rem
  panel-padding: 1.25rem
  screen-margin-desktop: 1.5rem
  screen-margin-mobile: 0.75rem
---

## Brand & Style

This design system delivers mission-critical geospatial intelligence, combining the density and precision of high-frequency financial terminals with the fluid minimalism of modern engineering platforms and atmospheric AAA visualization. 

Designed for disaster response command centers, regional hydrologists, district emergency officers, and on-ground rescue personnel across India, the UI projects unwavering computational authority, instantaneous spatial clarity, and life-saving readiness. The interface strips away decorative friction, replacing it with deep charcoal atmospheric depths, hyper-precise vector telemetry, laser-sharp glowing status indicators, and luminous data visualizations.

The aesthetic fuses **Tactical Technical Minimalism** with **Atmospheric Glassmorphism**:
- Ultra-dense informational architecture with razor-thin hairline dividers (`1px`).
- Translucent command modules floating over live radar arrays and bathymetric terrain models.
- Functional phosphorescent glow states reserved exclusively for actionable real-time states: water level spikes, emergency inundation vectors, sensor drops, and safe evacuation corridors.

## Colors

The color palette operates strictly on semantic urgency and sensory tiering within an ultra-dark tactical spectrum. 

### Canvas & Surfaces
- **Void Obsidian (`#06080F`)**: Root viewport background, map underlay canvas, and inactive base layer.
- **Trench Slate (`#0B0F19`)**: Primary surface for glassmorphic dock panels, floating tactical cards, and sidebars.
- **Deep Marine (`#121826`)**: Elevated tooltips, dropdown menus, context inspectors, and active segment wells.
- **Hairline Boundary (`rgba(255, 255, 255, 0.08)`)**: Structural borders to establish element edges without visual noise.

### Telemetry & Signal Accents
- **Hydro Cyan (`#00D9FF`)**: Primary brand and meteorological radar axis. Signifies active precipitation, cloud burst tracking, radar scans, active sensor ping, and focal UI selections.
- **Inundation Amber (`#FF6B35`)**: Secondary dynamic indicator. Designates rising water tables, surge vectors, flash flood watch advisories, and hydrological model predictions.
- **Critical Crimson (`#FF073A`)**: Highest alert tier. Reserved strictly for dam breach forecasts, extreme submergence, localized SOS alerts, and critical telemetry loss. Must trigger active glow pulses (`rgba(255, 7, 58, 0.35)`).
- **Safe Emerald (`#10B981`)**: Evacuation passages, safe muster points, operational sensor nodes, and nominal catchment levels.
- **WhatsApp Relay Green (`#25D366`)**: Direct civic broadcasts, low-bandwidth mesh alerts, and public dispatch validation.
- **Telemetry Muted (`#64748B`)**: Grid ticks, axis markings, sensor serials, timestamps, and resting data states.

## Typography

Typographic hierarchy enforces strict separation between high-level situational awareness, contextual microcopy, and raw instrument readouts:

- **Space Grotesk (Display & Spatial Coordinates)**: Used for high-impact metric rollups, station names, sector codes, and modal headers. Its geometric structure evokes aerospace instrumentation while remaining crisp against dark map tiles.
- **Inter (Microcopy, Explanatory UI, Form Controls)**: Serves as the high-legibility interface spine. Used for descriptive alerts, action directives, multi-lingual translations, tooltips, and system notifications.
- **JetBrains Mono (Telemetry, Model Parameters, Confidence Intervals)**: Exclusively employed for data grids, lat/long coordinates, water discharge rates (cumecs), runoff velocity, and inference timestamps. Tabular figures ensure uniform alignment across high-frequency dashboard updates without shifting layouts.

## Layout & Spacing

The layout model is anchored on an **Adaptive Multi-Pane Flight-Deck Grid** engineered for massive screen estate (command wall 4K displays) down to rugged mobile field-units:

- **Base Rhythm**: A strict 4px/8px incremental rhythm governs all padding, gaps, and positioning.
- **Desktop (1440px+)**: Dynamic multi-column layout with a dominant full-viewport GIS canvas (`z-index: 0`), anchored left telemetry panel (380px fixed width), bottom temporal timeline scrubber (`height: 84px`), and right floating contextual diagnostic inspector (420px collapsable).
- **Tablet (768px - 1439px)**: Split-screen HUD with slide-over drawers; map remains persistent; panel docks compress to icon-pinned side rails.
- **Mobile (<768px)**: Stacked single-column card sequence over a persistent mini-map preview, transitioning to bottom-sheet inspection states for critical village-level advisories. Gutters contract to 12px (`0.75rem`) to maximize information density.

## Elevation & Depth

Visual hierarchy uses physical back-illumination, translucent glass stratification, and crisp neon ambient dissipation rather than standard dropshadows:

- **Base Layer (Elevation 0 - Substrate)**: Solid `#06080F` rendering base map tiles, vector bathymetry, and satellite contours.
- **Dock Layer (Elevation 1 - Structural Panels)**: `background: rgba(11, 15, 25, 0.72)` paired with `backdrop-filter: blur(16px)` and a continuous hairline frame `border: 1px solid rgba(255, 255, 255, 0.08)`.
- **Flyout & Context Layer (Elevation 2 - Active Inspectors)**: `background: rgba(18, 24, 38, 0.88)` with `backdrop-filter: blur(24px)`, framed by directional edge highlights (`box-shadow: inset 0 1px 0 0 rgba(255, 255, 255, 0.12)`).
- **Critical Breach & Alert Layer (Elevation 3 - Floating Overlays & Emergency Modals)**: Translucent tinted backdrops featuring active chromatic edge glows:
  - Cyan Monitor: `box-shadow: 0 0 24px -4px rgba(0, 217, 255, 0.35)`
  - Amber Inundation: `box-shadow: 0 0 24px -4px rgba(255, 107, 53, 0.35)`
  - Emergency SOS: `box-shadow: 0 0 32px 0px rgba(255, 7, 58, 0.45)` with subtle 1.5s ease pulse.

## Shapes

The design system maintains a **Soft-Edged Tactical Geometry** (`roundedness: 1`). Corners are disciplined, technical, and engineered rather than overly organic or bulbous:

- Base cards, data tables, map controls, and input groups carry an exact `4px` (`0.25rem`) radius to preserve high-density grid alignment.
- Primary floating modal panels, radar HUD viewports, and floating action docks use `8px` (`0.5rem`).
- Indicator pills, telemetry status pings, and filter chips use a clean `4px` or full radial pill shape where micro-tagging requires distinct visual differentiation from data fields.

## Components

### Action Controls (Buttons)
- **Primary Cyber (Inference Trigger/Action)**: Gradient background (`linear-gradient(180deg, #00D9FF 0%, #0099CC 100%)`), text `#06080F` Space Grotesk Bold, with `box-shadow: 0 0 16px rgba(0, 217, 255, 0.4)`. In hover state, brightness increases by 10%.
- **Emergency Crimson (Broadcast SOS / Evac Dispatch)**: Solid `#FF073A`, text `#FFFFFF`, active 1.2s perimeter glow animation.
- **Secondary Glass**: `background: rgba(255, 255, 255, 0.04)`, `border: 1px solid rgba(255, 255, 255, 0.12)`, text `#FFFFFF` Inter Medium. Hover state transitions border to Hydro Cyan (`#00D9FF`).

### Status Badges & Chips
- Ultra-compact with `padding: 2px 6px` and typography `telemetry-caption`.
- **Nominal**: Background `rgba(16, 185, 129, 0.12)`, border `1px solid rgba(16, 185, 129, 0.3)`, text `#10B981` accompanied by a 4px solid pulsing center dot.
- **Critical Alert**: Background `rgba(255, 7, 58, 0.16)`, border `1px solid rgba(255, 7, 58, 0.5)`, text `#FF073A`.

### Data Cards & Modules
- Glassmorphic panels with top-right tactical corner marks or tiny coordinate tags in `JetBrains Mono`.
- Sub-divided with hairline separators (`rgba(255, 255, 255, 0.06)`).
- Metric values presented in `Space Grotesk` with unit measures and variance deltas rendered in `JetBrains Mono`.

### Form Inputs & Terminal Controls
- Dark recessed wells (`background: rgba(6, 8, 15, 0.6)`), `border: 1px solid rgba(255, 255, 255, 0.1)`, caret color `#00D9FF`.
- Focus states trigger instantaneous border transition to `#00D9FF` and subtle 4px exterior glow.
- Checkboxes and toggles render in sharp geometry: unchecked states use faint outline boxes; checked states fill with `#00D9FF` accompanied by crisp contrast glyphs.

### Specialized Hydrological Components
- **River Basin Level Gauge**: Vertical or horizontal progressive bar with graduated warning zones (Safe, Alert, Danger, Overflow), featuring glowing meniscus line indicator.
- **Time Scrubber (48h AI Runoff Prediction)**: Scrubbable timeline with translucent rainfall histogram bars and interactive scrub-head showing confidence ribbons (P10/P50/P90).
- **Civil Dispatch Module**: One-click WhatsApp alert dispatch preview card with payload payload character count, geo-fenced reach stats, and low-latency delivery confirmation.